
package id.ac.upb.asetpinjam.katalog;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import id.ac.upb.asetpinjam.model.Aset;
import id.ac.upb.asetpinjam.model.JenisAset;

public class KatalogAset {

    private final List<Aset> daftar = new ArrayList<>();

    public void tambah(Aset aset) {
        daftar.add(aset);
    }

    public List<Aset> semua() {
        return List.copyOf(daftar);
    }

    public List<Aset> cari(String kata) {
        List<Aset> hasil = new ArrayList<>();

        String pencarian = kata.toLowerCase(Locale.ROOT);

        for (Aset aset : daftar) {
            if (aset.getNama().toLowerCase(Locale.ROOT)
                    .contains(pencarian)) {
                hasil.add(aset);
            }
        }

        return hasil;
    }

    public List<Aset> cari(String kata, JenisAset jenis) {
        List<Aset> hasil = new ArrayList<>();

        String pencarian = kata.toLowerCase(Locale.ROOT);

        for (Aset aset : daftar) {
            if (aset.getNama().toLowerCase(Locale.ROOT)
                    .contains(pencarian)
                    && aset.getJenis() == jenis) {
                hasil.add(aset);
            }
        }

        return hasil;
    }
}
